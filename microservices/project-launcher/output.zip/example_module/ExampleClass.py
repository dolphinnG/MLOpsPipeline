
class ExampleClass:
    def __init__(self):
        print("ExampleClass instantiated")

    def example_method(self):
        return "Hello, example!"